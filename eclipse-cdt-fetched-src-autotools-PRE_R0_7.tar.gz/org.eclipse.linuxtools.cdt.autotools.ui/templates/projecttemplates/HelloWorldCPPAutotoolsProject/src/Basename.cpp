/*
 ============================================================================
 Name        : $(baseName).cpp
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : Hello World in C++,
 ============================================================================
 */

#include <iostream>

using namespace std;

int main(void) {
	cout << "$(message)" << endl; /* prints $(message) */
	return 0;
}
